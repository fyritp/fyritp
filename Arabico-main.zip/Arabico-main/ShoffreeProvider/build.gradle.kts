version = 2

cloudstream {
    description = ""
    authors = listOf( "kingslayer_007" )

    language = "ar"
	
    status = 1

    tvTypes = listOf( "TvSeries" , "Movie" )

    iconUrl = "https://www.google.com/s2/favicons?domain=shoffree.top&sz=%size%"
}
